"""Google Scholar citation analyzer package."""

__version__ = "0.1.0"

# Set up package-level logger
import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())