# Scholar Citations

A tool for analyzing self-citations in Google Scholar profiles.

## Installation